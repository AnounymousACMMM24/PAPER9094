
```bash
bash run.sh
