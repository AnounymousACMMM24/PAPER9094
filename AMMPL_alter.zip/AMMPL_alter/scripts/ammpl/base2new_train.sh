#!/bin/bash

#cd ../..

# custom config
DATA=E:/Codes/DATA
TRAINER=CoCoOp
#TRAINER=CoOp

DATASET=$1
#SEED=$2

CFG=vit_b16_c4_ep10_batch1_ctxv1
SHOTS=16

for RATE in 0.85 0.90 0.91 0.92 0.93 0.94 0.95 0.96 0.97 0.98
do
  for SEED in 1 2 3
  do
    DIR=output/base2new/train_base/${DATASET}/shots_${SHOTS}/${TRAINER}/${CFG}/${RATE}/seed${SEED}
        python train.py \
        --root ${DATA} \
        --seed ${SEED} \
        --trainer ${TRAINER} \
        --dataset-config-file configs/datasets/${DATASET}.yaml \
        --config-file configs/trainers/${TRAINER}/${CFG}.yaml \
        --output-dir ${DIR} \
        DATASET.NUM_SHOTS ${SHOTS} \
        TRAINER.COCOOP.RATE ${RATE}\
        DATASET.SUBSAMPLE_CLASSES base
  done
done