#!/bin/bash

# custom config
DATA=E:/Codes/DATA
TRAINER=CoCoOp

DATASET=$1

CFG=vit_b16_c4_ep10_batch1_ctxv1
SHOTS=16
LOADEP=10
SUB=new

for RATE in 0.85 0.90 0.91 0.92 0.93 0.94 0.95 0.96 0.97 0.98
do
  for SEED in 1 2 3
  do
    COMMON_DIR=${DATASET}/shots_${SHOTS}/${TRAINER}/${CFG}/${RATE}/seed${SEED}
    MODEL_DIR=output/base2new/train_base/${COMMON_DIR}
    DIR=output/base2new/test_${SUB}/${COMMON_DIR}
      python train.py \
      --root ${DATA} \
      --seed ${SEED} \
      --trainer ${TRAINER} \
      --dataset-config-file configs/datasets/${DATASET}.yaml \
      --config-file configs/trainers/${TRAINER}/${CFG}.yaml \
      --output-dir ${DIR} \
      --model-dir ${MODEL_DIR} \
      --load-epoch ${LOADEP} \
      --eval-only \
      DATASET.NUM_SHOTS ${SHOTS} \
      DATASET.SUBSAMPLE_CLASSES ${SUB} \
      TRAINER.COCOOP.WAY 0
  done
done