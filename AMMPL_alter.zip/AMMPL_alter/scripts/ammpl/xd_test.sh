#!/bin/bash

#cd ../..

# custom config
DATA=E:/Codes/DATA
#TRAINER=CoOp
TRAINER=CoCoOp

DATASET=$1
SHOTS=1
CFG=vit_b16_c4_ep10_batch1_ctxv1

for SEED in 1 2 3
do
  for RATE in 0.85 0.90 0.91 0.92 0.93 0.94 0.95 0.96 0.97 0.98
  do
    DIR=output/evaluation/${TRAINER}/${CFG}_${SHOTS}shots/${DATASET}/${RATE}/seed${SEED}
    python train.py \
    --root ${DATA} \
    --seed ${SEED} \
    --trainer ${TRAINER} \
    --dataset-config-file configs/datasets/${DATASET}.yaml \
    --config-file configs/trainers/${TRAINER}/${CFG}.yaml \
    --output-dir ${DIR} \
    --model-dir output/${DATASET}/${TRAINER}/${CFG}_${SHOTS}shots/nctx16/RATE${RATE}/seed${SEED} \
    --load-epoch 8 \
    --eval-only \
    TRAINER.COCOOP.WAY 0
  done
done

