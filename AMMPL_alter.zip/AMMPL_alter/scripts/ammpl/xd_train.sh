#!/bin/bash

#cd ../..
# custom config
DATA=E:/Codes/DATA
TRAINER=CoCoOp
DATASET=$1
CFG=vit_b16_c4_ep10_batch1_ctxv1
SHOTS=1

for SEED in 1 2 3
do
  for RATE in 0.85 0.90 0.91 0.92 0.93 0.94 0.95 0.96 0.97 0.98
  do
    DIR=output/${DATASET}/${TRAINER}/${CFG}_${SHOTS}shots/nctx16/RATE${RATE}/seed${SEED}
    if [ -d "$DIR" ]; then
        echo "Oops! The results exist at ${DIR} (so skip this job)"
    else
        python train.py \
        --root ${DATA} \
        --seed ${SEED} \
        --trainer ${TRAINER} \
        --dataset-config-file configs/datasets/${DATASET}.yaml \
        --config-file configs/trainers/${TRAINER}/${CFG}.yaml \
        --output-dir ${DIR} \
        TRAINER.COCOOP.RATE ${RATE}\
        DATASET.NUM_SHOTS ${SHOTS}
    fi
  done
done