#!/bin/bash

bash scripts/ammpl/xd_train.sh caltech101

bash scripts/ammpl/xd_test.sh caltech101







